extends Node3D

@onready var grid_map: GridMap = $GridMap
@onready var player: CharacterBody3D = $CharacterBody3D

const WORLD_SIZE = 75
const MAX_HEIGHT = 25


func _ready() -> void:
	player.global_position = Vector3(float(WORLD_SIZE) / 2.0, 30.0, float(WORLD_SIZE) / 2.0)
	generate_world()

func generate_world() -> void:
	var noise = FastNoiseLite.new()
	noise.seed = randi()
	noise.noise_type = FastNoiseLite.TYPE_PERLIN
	noise.frequency = 0.08
	
	for x in range(WORLD_SIZE):
		for z in range(WORLD_SIZE):
			var noise_val = (noise.get_noise_2d(x, z) + 1.0) / 2.0
			var height = int(noise_val * MAX_HEIGHT) + 3
			
			for y in range(height):
				var random = randi_range(0, 2)
				grid_map.set_cell_item(Vector3i(x, y, z), random)
