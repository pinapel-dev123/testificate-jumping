extends Control


func LEVEL1() -> void:
	Global.change_scene("res://main-game/LEVEL/LEVEL1.tscn")


func LEVEL2() -> void:
	Global.change_scene("res://main-game/LEVEL/LEVEL2.tscn")


func LEVEL3() -> void:
	Global.change_scene("res://main-game/LEVEL/LEVEL3.tscn")


func LEVEL4() -> void:
	Global.change_scene("res://main-game/LEVEL/LEVEL4.tscn")

func _on_back_pressed() -> void:
	Global.change_scene("res://main-menu/main.tscn")
