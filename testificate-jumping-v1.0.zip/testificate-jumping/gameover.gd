extends Node


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE


func _on_back_pressed() -> void:
	Global.change_scene("res://main-menu/main.tscn")
