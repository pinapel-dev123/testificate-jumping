extends Node

func _on_back_pressed() -> void:
	Global.change_scene("res://main-menu/main.tscn")
